from flask import Flask, render_template
from wtforms import Form, StringField, validators

app = Flask(__name__)

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/layout')
def layout():
    return render_template('layout.html')

@app.route('/layout1')
def layout1():
    return render_template('layout1.html')

@app.route('/login')
def login():
    return render_template('login.html')

if __name__ == '__main__':
    app.run()
